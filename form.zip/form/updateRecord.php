<?php
    $Id = $_POST['Id'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $mnumber = $_POST['mnumber'];
    $gender = $_POST['gender'];
    $hobbies = $_POST['hobbies'];
    $course = $_POST['course'];
    $comments = $_POST['comments'];
  
        $conn = mysqli_connect("localhost","root","seasia@123","registrations") or die ("connection failed");
        $sql = "UPDATE user SET firstName = '{$firstName}',lastName = '{$lastName}',email = '{$email}',mnumber ='{$mnumber}',gender ='{$gender}',hobbies ='{$hobbies}',course ='{$course}',comments ='{$comments}' WHERE Id = {$Id}";
        $result = mysqli_query($conn, $sql); //or die ("Record not saved");
        if ($result==1) {
            echo"<script>alert('Your record has been saved Sucessfully');</script>";
        } else {
            echo"<script>alert('Record Not Saved');</script>";
        }
        header("location: http://localhost/form/display.php");
        mysqli_close($conn);
?>

