<?php
  $firstName = $_POST['firstName'];
  $lastName = $_POST['lastName'];
  $email = $_POST['email'];
  $mnumber = $_POST['mnumber'];
  $gender = $_POST['gender'];
  $hobbies = $_POST['hobbies'];
  $course = $_POST['course'];
  $comments = $_POST['comments'];
  

  $conn = mysqli_connect("localhost","root","seasia@123","registrations") or die ("connection failed");
  $sql = " INSERT INTO user (firstName, lastName, email, mnumber, gender, hobbies, course, comments )
          VALUES ('$firstName', '$lastName', '$email', '$mnumber', '$gender', '$hobbies', '$course','$comments')";
  $result = mysqli_query($conn, $sql);
      if ($result==1) {
          echo"<script>alert('Your record has been saved Sucessfully');</script>";
      } else {
          echo"<script>alert('Record Not Saved');</script>";
      }
     header("location: http://localhost/form/display.php");
      mysqli_close($conn);
?>



